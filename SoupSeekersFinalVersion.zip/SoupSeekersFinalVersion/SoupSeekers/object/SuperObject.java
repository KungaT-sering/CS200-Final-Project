package object;

import java.awt.image.BufferedImage;
import main.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;

/**
 * SuperObject class is the super class for all the objects that gets drawn onto the map. has properties like
 * the name of the object, the image itself, collision, and coordinates.
 * @author Reagan Hennen and Kunga Tsering
 */
public class SuperObject{
  
  /**
   * Image representation of the object
   */
  public BufferedImage image;
  
  /**
   * Name of the object
   */
  public String name;
  
  /**
   * Whether the object has collision enabled or not.
   */
  public boolean collision = false;
  
  /**
   * The x and y coordinate of the object in the game world.
   */
  public int worldX, worldY;
  
  /**
   * This draw method is what puts the objects themselves onto the map. Takes into account the player's position to
   * make sure the object is put within the visible screen area.
   * @param g2 Graphics2D the instance used for rendering.
   * @param gp GameLayout the instance containing the player's position and screen information.
   */ 
  public void draw(Graphics2D g2, GameLayout gp){
    
    int screenX = worldX - gp.player.x + gp.player.screenX;
    int screenY = worldY - gp.player.y + gp.player.screenY;
    if (worldX + gp.tileSize > gp.player.x - gp.player.screenX &&
        worldX - gp.tileSize < gp.player.x + gp.player.screenX &&
        worldY + gp.tileSize > gp.player.y - gp.player.screenY &&
        worldY - gp.tileSize < gp.player.y + gp.player.screenY){
       g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
    }
  }
  
}