package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

  
 /**
   * OBJ_Enemy class represents the specific object in the game that is called, badenemy. Extends SuperObject so has all
   * the properties of SuperObject.
   */  
  public class OBJ_Enemy extends SuperObject{
  
 /**
   * The constructor setting up the unique png file and name.
   */
  public OBJ_Enemy(){
    
    name = "BadEnemy";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/BadEnemy.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}