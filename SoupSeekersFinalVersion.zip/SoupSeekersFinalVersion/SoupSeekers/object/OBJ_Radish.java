
package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

   /**
   * OBJ_Radish class represents the specific object in the game that is called, Radish. Extends SuperObject so has all
   * the properties of SuperObject.
   */
  public class OBJ_Radish extends SuperObject{
  
     /**
   * Constructor that sets the image to the radish png along with setting the name equal to radish.
   */
  public OBJ_Radish(){
    
    name = "Radish";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/Radish.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}