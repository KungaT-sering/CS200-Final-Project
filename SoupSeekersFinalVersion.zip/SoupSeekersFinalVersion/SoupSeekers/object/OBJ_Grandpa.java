
package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

  /**
   * The OBJ_Grandpa class is a specific object in the game called grandpa, that extends SuperObject getting all
   * its properties.
   */
  public class OBJ_Grandpa extends SuperObject{
  
    /**
     * The constructor that sets up the name and image.
     */
  public OBJ_Grandpa(){
    
    name = "Grandpa";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/grandpa.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}