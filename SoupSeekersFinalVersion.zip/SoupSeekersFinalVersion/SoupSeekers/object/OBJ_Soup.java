
package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

  /**
   * OBJ_Soup class represents the specific object in the game that is called, Soup. Extends SuperObject so has all
   * the properties of SuperObject.
   */
  public class OBJ_Soup extends SuperObject{
  
  /**
   * Constructor that sets the image to the soup png along with setting the name equal to soup.
   */
  public OBJ_Soup(){
    
    name = "Soup";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/Soup.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}