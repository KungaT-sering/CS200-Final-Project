
package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

     /**
   * OBJ_PokeBall class represents the specific object in the game that is called, Pokeball. Extends SuperObject so has all
   * the properties of SuperObject.
   */
public class OBJ_PokeBall extends SuperObject{
  
  /**
   * The constructor setting up the unique png file and name.
   */
  public OBJ_PokeBall(){
    
    name = "PokeBall";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/Pokeball.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}