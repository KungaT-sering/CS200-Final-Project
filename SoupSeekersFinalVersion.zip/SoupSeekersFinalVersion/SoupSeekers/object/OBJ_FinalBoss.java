
package object;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;

 /**
   * OBJ_FinalBoss class represents the specific object in the game that is called, FinalBoss. Extends SuperObject so has all
   * the properties of SuperObject.
   */  
  public class OBJ_FinalBoss extends SuperObject{
    /**
   * The constructor setting up the unique png file and name.
   */
  public OBJ_FinalBoss(){
    
    name = "FinalBoss";
    try{
      image = ImageIO.read(getClass().getResourceAsStream("/assets/FinalBoss.png"));
      
    }
    catch(IOException e){
      
      e.printStackTrace();
    }
  }
  
}