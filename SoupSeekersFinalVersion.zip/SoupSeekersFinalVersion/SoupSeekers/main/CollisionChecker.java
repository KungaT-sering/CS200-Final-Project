package main;
/**
 * The CollisionChecker class is responsible for detecting collisions between the player or other entities
 * and the tiles in the game world. It provides methods to check if the player is on a "jumping" tile
 * and to check for collisions with tiles when the player or an entity moves in different directions.
 * @author Reagan Hennen and Kunga Tsering
 */
public class CollisionChecker{
  /*
   *Reference to the GameLayout instance, which holds game objects and data 
   */
  GameLayout gp;
  /**
     * Constructor that initializes the CollisionChecker with the provided GameLayout.
     * 
     * @param gp The GameLayout instance that holds the game's objects and data.
     */
  public CollisionChecker(GameLayout gp){
   this.gp = gp; 
  }
  
  /**
     * Checks if the player is currently standing on a "jumping" tile. 
     * A "jumping" tile is a special tile that allows the player to jump or interact with it in some way.
     * 
     * @return True if the player is on a jumping tile, false otherwise.
     */
  public boolean isOnJumpingTile(){
   
    
    
    int leftX = gp.player.x + gp.player.solidArea.x;
    int rightX = gp.player.x + gp.player.solidArea.x + gp.player.solidArea.width;
    int topY = gp.player.y + gp.player.solidArea.y;
    int bottomY = gp.player.y + gp.player.solidArea.y + gp.player.solidArea.height;
    
    int leftTileX = leftX / gp.tileSize;
    int rightTileX = rightX / gp.tileSize;
    int topTileY = topY / gp.tileSize;
    int bottomTileY = bottomY / gp.tileSize;
    
    int topLeftTile = gp.tileM.mapTileNum[leftTileX][topTileY];
    int topRightTile = gp.tileM.mapTileNum[rightTileX][topTileY];
    int bottomLeftTile = gp.tileM.mapTileNum[leftTileX][bottomTileY];
    int bottomRightTile = gp.tileM.mapTileNum[rightTileX][bottomTileY];
    
    return (gp.tileM.tile[topLeftTile].switchMap || gp.tileM.tile[topRightTile].switchMap || gp.tileM.tile[bottomLeftTile].switchMap || gp.tileM.tile[bottomRightTile].switchMap);
    
    
  }
  
   /**
     * Checks for collisions between the provided entity and the tiles in the game world.
     * This method checks the entity's collision box against the tiles in the direction the entity is moving.
     * 
     * @param entity The entity (e.g., player or enemy) to check for tile collisions.
     */
  public void checkTile(Entity entity){
    
    // collision box sizes
    int entityLeftX = entity.x + entity.solidArea.x;
    int entityRightX = entity.x + entity.solidArea.x + entity.solidArea.width;
    int entityTopY = entity.y + entity.solidArea.y + entity.solidArea.height;
    int entityBottomY = entity.y + entity.solidArea.y + entity.solidArea.height;
    
    int entityLeftCol = entityLeftX/gp.tileSize;
    int entityRightCol = entityRightX/gp.tileSize;
    int entityTopRow = entityTopY/gp.tileSize;
    int entityBottomRow = entityBottomY/gp.tileSize;
    
    int tileNum1, tileNum2;
    
    switch(entity.direction){
      case "up": 
        entityTopRow = (entityTopY - entity.speed)/gp.tileSize;
        tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
        tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
        if (gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
          entity.collisionOn = true;
        }
        break;
      case "down":
        entityBottomRow = (entityBottomY + entity.speed)/gp.tileSize;
        tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
        tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
        if (gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
          entity.collisionOn = true;
        }
        break;
      case "left":
        entityLeftCol = (entityLeftX - entity.speed)/gp.tileSize;
        tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
        tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
        if (gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
          entity.collisionOn = true;
        }
                
        break;
      case "right":
        entityRightCol = (entityRightX + entity.speed)/gp.tileSize;
        tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
        tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
        if (gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
          entity.collisionOn = true;
        }
        
        break;
    }
    
    
  }
}