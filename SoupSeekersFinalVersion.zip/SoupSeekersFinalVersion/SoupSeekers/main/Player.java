package main;
import main.*;
import java.awt.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.*;
/**
 * class for the player
 * @author Reagan Hennen and Kunga Tsering
 */
public class Player extends Entity{
  
  /**
   * instance of game layout
   */
  GameLayout gp;
  /**
   * instance of key handler class
   */
  KeyHandler keyH;
  /**
   * The X-coordinate on the screen where the player is drawn.
   */
  public final int screenX;
  /**
   * The Y-coordinate on the screen where the player is drawn.
   */
  public final int screenY;
  
  /**
   * Constructs a new player object and initializes its properties.
   * It sets up the player's starting position, collision area, and sprite images.
   *
   * @param gp The GameLayout instance that holds game data.
   * @param keyH The KeyHandler instance for handling player input.
   */
  public Player(GameLayout gp, KeyHandler keyH){
    this.gp = gp;
    this.keyH = keyH;
    
    
    
    // collision box
    solidArea = new Rectangle();
    solidArea.x = 8;
    solidArea.y = 16;
    solidArea.width = 32;
    solidArea.height = 32;
    
    screenX = gp.screenWidth/2 - (gp.tileSize/2);
    screenY = gp.screenHeight/2 - (gp.tileSize/2);
    
    setDefaultValues();
    getPlayerImage();
    
    
    
  }
  /**
   * Sets the default values for the player's attributes, such as position, speed, and direction.
   */
  public void setDefaultValues(){
    x = 100;
    y = 100;
    speed = 4;
    direction = "down";
  }
  /**
   * Loads the player's sprite images for movement and standing in each direction.
   * The images are read from the resources folder and stored as BufferedImage objects.
   */
  public void getPlayerImage(){
    try {
      up1 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Up Move 1.png"));
      up2 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Up Move 2.png"));
      down1 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Down Move 1.png"));
      down2 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Down Move 2.png"));
      left1 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Left Move 1.png"));
      left2 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Left Move 2.png"));
      right1 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Right Move 1.png"));
      right2 = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Right Move 2.png"));
      
      up = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Up Standing.png"));
      down = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Down Standing.png"));
      left = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Left Standing.png"));
      right = ImageIO.read(getClass().getResourceAsStream("/assets/Nagaer Right Standing.png"));
      
    } catch (IOException e){
      e.printStackTrace();
    }
    
    
  }
  /**
   * Determines the current tile the player is on based on the player's position.
   *
   * @param tileManager The TileManager instance used to access the map's tile data.
   * @return The tile number at the player's current location.
   */
  public int getCurrentTile(TileManager tileManager){
    int tileX = (int) (this.x / 32);
    int tileY = (int) (this.y / 32);
    return tileManager.mapTileNum[tileY][tileX];
  }
  
  
  /**
   * Updates the player's position and sprite. It checks the player's input for movement direction,
   * processes collision detection, and changes the player's sprite depending on movement.
   */
  public void update(){
    
    
    if (keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true){
      if (keyH.upPressed == true){
        direction = "up";
        
      }
      else if(keyH.downPressed == true){
        direction = "down";
        
      }
      else if (keyH.leftPressed == true){
        direction = "left";
        
      }else if (keyH.rightPressed == true){
        direction = "right";
        
      }
      // this will check the tile collision
      collisionOn = false;
      gp.cChecker.checkTile(this);
      
      // if the collision is false then the player can move.
      if (collisionOn == false){
        
        switch (direction){
          case "up":
            y -= speed;
            break;
          case "down":
            y += speed;
            break;
          case "left":
            x -= speed;
            break;
          case "right":
            x += speed;
            break;
            
        }
        
      }
      
      spriteCounter++;
      if (spriteCounter > 12){
        if (spriteNum == 1){
          spriteNum = 3; 
        } else if (spriteNum == 2){
          spriteNum = 1; 
        } else if (spriteNum == 3){
          spriteNum = 2;
        }
        spriteCounter = 0;
      }
    } else if (direction == "up" || direction == "down" || direction == "left" || direction == "right"){
      spriteNum = 3; 
    }
    
    
    
  }
  
  /**
   * Draws the player's sprite on the screen based on the current direction and sprite number.
   *
   * @param g2 The Graphics2D object used for drawing the player.
   */
  public void draw(Graphics2D g2){
    
    
    BufferedImage image = null;
    switch(direction){
      case "up":
        if (spriteNum == 1){
        image = up1;
      }
        if (spriteNum == 2){
          image = up2; 
        }
        if (spriteNum == 3){
          image = up; 
        }
        break;
      case "down":
        if (spriteNum == 1){
        image = down1;
      }
        if (spriteNum == 2){
          image = down2; 
        }
        if (spriteNum == 3){
          image = down; 
        }
        break;
      case "left":
        if (spriteNum == 1){
        image = left1;
      }
        if (spriteNum == 2){
          image = left2;
        }
        if (spriteNum == 3){
          image = left; 
        }
        break;
      case "right":
        if (spriteNum == 1){
        image = right1;
      }
        if (spriteNum == 2){
          image = right2;
        }
        if (spriteNum == 3){
          image = right; 
        }
        break;
    }
    g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
    
    
  }
}