package main;

/**
 * The LocationDescription class represents a description of a location in the game.
 * It holds the description text and also includes a marking feature that can be used
 * to indicate whether a location has been marked or not (for example, for tracking purposes).
 * @author Reagan Hennen and Kunga Tsering
 */
public class LocationDescription {
    
    // The description of the location.
    private String description;
    
    // Flag to mark the location (default is false).
    private boolean mark = false;

    /**
     * Constructs a new LocationDescription with the given description.
     * The location is initially unmarked.
     * 
     * @param description The description of the location.
     */
    public LocationDescription(String description) {
        this.description = description;
    }

    /**
     * Retrieves the description of the location.
     * 
     * @return The description of the location.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Marks the location. After calling this method, the location is marked.
     */
    public void mark() {
        this.mark = true;
    }

    /**
     * Unmarks the location. After calling this method, the location is no longer marked.
     */
    public void unmark() {
        this.mark = false;
    }

    /**
     * Checks whether the location is marked.
     * 
     * @return true if the location is marked, false otherwise.
     */
    public boolean getMark() {
        return this.mark;
    }
    
    
}
