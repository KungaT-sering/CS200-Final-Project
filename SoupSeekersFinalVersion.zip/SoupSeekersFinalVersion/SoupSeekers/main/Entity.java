package main;
import java.awt.image.*;
import java.awt.*;

/**
 * This class serves as a base for entities like characters
 * @author Reagan Hennen and Kunga Tsering
 */
public class Entity{
  /**
   * The x-coordinate of the entity's position.
   */
  public int x;
  /**
   * The y-coordinate of the entity's position.
   */
  public int y;
  /**
   * The speed at which the entity moves.
   */
  public int speed;
  /**
   * images representing the characters movement
   */
  public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2, up, down, left, right;
  /**
   * Possible values include: "up", "down", "left", "right".
   */
  public String direction;
  /**
   * A counter to track sprite animation cycles.
   * This value is incremented each time the entity moves.
   */
  public int spriteCounter = 0;
  /**
   * The current sprite frame being displayed for animation.
   * This alternates between 1 and 2 for sprite animation.
   */
  public int spriteNum = 1;
  /**
   *
   * This area is used for collision detection.
   */
  public Rectangle solidArea;
  /**
   * A boolean indicating whether a collision has occurred or not.
   * This flag is used to prevent the entity from passing through obstacles.
   */
  public boolean collisionOn = false;
}