package main;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import object.*;

/**
 * The GameLayout class represents the overall layout of a game world. It manages the locations (nodes) in the game
 * and the connections (edges) between them. It also stores descriptions of each location.
 * This class handles loading the game world data from files, saving game states, and supporting traversal of locations.
 * @author Reagan Hennen and Kunga Tsering
 */
public class GameLayout extends JPanel implements Runnable{
  
  private HashMap<String, Set<Edge>> connections;  // Map storing directed edges for each location
  private HashMap<String, LocationDescription> descriptions;  // Map storing location descriptions
  
  /**
   * Constructs a GameLayout object and loads the game world data from two files: 
   * one for the connections between locations and one for the descriptions of each location.
   *
   * @param connectionsFile The path to the file containing connections between locations.
   * @param descriptionsFile The path to the file containing descriptions of locations.
   */
  public GameLayout(String connectionsFile, String descriptionsFile) {
    this.connections = new HashMap<>();
    this.descriptions = new HashMap<>();
    
    // Load connections and descriptions from the respective files
    loadConnections(connectionsFile);
    loadDescriptions(descriptionsFile);
  }
  
  /**
   * Loads the connections (edges) from a file and populates the connections map.
   *
   * @param fileName The name of the file containing connection data.
   */
  private void loadConnections(String fileName) {
    try (Scanner fileSC = new Scanner(new File(fileName))) {
      while (fileSC.hasNextLine()) {
        String line = fileSC.nextLine().trim();
        Scanner lineSC = new Scanner(line);
        if (lineSC.hasNext()) {
          String source = lineSC.next();
          // Ensure the source is in the map even if it has no outgoing edges
          
          if (!this.connections.containsKey(source)){
            this.connections.put(source, new HashSet<>());
          }
          
          while (lineSC.hasNext()) {
            String dest = lineSC.next();
            Edge edge = new Edge(source, dest);
            insert(edge);
          }
        }
        lineSC.close();
      }
    } catch (IOException ioe) {
      System.err.println("Error reading the connections file: " + ioe.getMessage());
    }
  }
  
  /**
   * Loads the descriptions of locations from a file and populates the descriptions map.
   *
   * @param fileName The name of the file containing location descriptions.
   */
  private void loadDescriptions(String fileName) {
    try (Scanner fileSC = new Scanner(new File(fileName))) {
      while (fileSC.hasNextLine()) {
        String line = fileSC.nextLine().trim();
        Scanner lineSC = new Scanner(line);
        if (lineSC.hasNext()) {
          String location = lineSC.next();
          if (lineSC.hasNext()) {
            String descriptionText = lineSC.nextLine().trim();
            LocationDescription description = new LocationDescription(descriptionText);
            addDescription(location, description);
          } else {
            System.err.println("No description found for location: " + line);
          }
        }
        lineSC.close();
      }
    } catch (IOException ioe) {
      System.err.println("Error reading the descriptions file: " + ioe.getMessage());
    }
  }
  
  /**
   * Inserts a directed edge into the connections map.
   *
   * @param edge The edge representing a connection between two locations.
   */
  private void insert(Edge edge) {
    String source = edge.getSource();
    Set<Edge> sourceConnections = this.connections.get(source);
    if (sourceConnections == null){
      sourceConnections = new HashSet<>();
      this.connections.put(source, sourceConnections);
    }
    sourceConnections.add(edge);  // Add the directed edge 
  }
  
  /**
   * Adds a description for a specific location.
   *
   * @param location The location identifier.
   * @param description The description of the location.
   */
  public void addDescription(String location, LocationDescription description) {
    this.descriptions.put(location, description);
  }
  
  /**
   * Retrieves the description of a specific location.
   *
   * @param location The location identifier.
   * @return The description of the location, or null if no description exists.
   */
  public LocationDescription getDescription(String location) {
    return this.descriptions.get(location);
  }
  
  /**
   * Returns an iterator that iterates over all locations in the game.
   *
   * @return An iterator over the locations in the game.
   */
  public Iterator<String> getLocationIterator() {
    return this.connections.keySet().iterator();
  }
  
  /**
   * Returns an iterator that iterates over all connected locations for a given location.
   *
   * @param location The location identifier for which connections are to be listed.
   * @return An iterator over the connected locations, or null if no connections exist for the location.
   */
  public Iterator<String> getConnectionsIterator(String location) {
    Set<Edge> sourceConnections = this.connections.get(location);
    if (sourceConnections == null) {
      return null;
    }
    
    Set<String> connectedLocations = new HashSet<>();
    for (Edge edge : sourceConnections) {
      connectedLocations.add(edge.getDest());
    }
    return connectedLocations.iterator();
  }
  
  /**
   * Performs a depth-first search (DFS) to find a location containing a desired property.
   *
   * @param startLocation The starting location for the search.
   * @param desiredProperty The property to search for within the descriptions of locations.
   * @return The location containing the desired property, or null if not found.
   */
  public String depthFirstSearch(String startLocation, String desiredProperty) {
    Set<String> visited = new HashSet<>();
    return dfsRecursive(startLocation, desiredProperty, visited);
  }
  
  /**
   * Recursive helper method for performing DFS to find a location with a specific property.
   *
   * @param currentLocation The current location during the search.
   * @param desiredProperty The property to search for.
   * @param visited A set of visited locations to avoid cycles.
   * @return The location that contains the desired property, or null if not found.
   */
  private String dfsRecursive(String currentLocation, String desiredProperty, Set<String> visited) {
    if (visited.contains(currentLocation)) {
      return null;  // Skip locations that have already been visited
    }
    
    visited.add(currentLocation);
    LocationDescription description = getDescription(currentLocation);
    if (description != null && description.getDescription().contains(desiredProperty)) {
      return currentLocation;  // Found the location
    }
    
    Set<Edge> sourceConnections = this.connections.get(currentLocation);
    if (sourceConnections != null) {
      for (Edge edge : sourceConnections) {
        String neighbor = edge.getDest();
        String result = dfsRecursive(neighbor, desiredProperty, visited);
        if (result != null) {
          return result;  // Return the found location
        }
      }
    }
    return null;  // No match found
  }
  
  /**
   * Saves the current game state (connections and descriptions) to the specified files.
   *
   * @param connectionsFile The file path to save connection data.
   * @param descriptionsFile The file path to save description data.
   */
  public void saveGameState(String connectionsFile, String descriptionsFile) {
    try (PrintWriter connectionsWriter = new PrintWriter(new FileWriter(connectionsFile));
         PrintWriter descriptionsWriter = new PrintWriter(new FileWriter(descriptionsFile))) {
           
           
           for (String source : connections.keySet()) {
             Set<Edge> sourceConnections = connections.get(source);
             for (Edge edge : sourceConnections) {
               connectionsWriter.println(edge.getSource() + " " + edge.getDest());
             }
           }
           connectionsWriter.println("B");
           connectionsWriter.println("D");
           
           for (Map.Entry<String, LocationDescription> entry : descriptions.entrySet()) {
             descriptionsWriter.println(entry.getKey() + " " + entry.getValue().getDescription());
           }
           
           //System.out.println("Game state saved successfully.");
         } catch (IOException ioe) {
           System.err.println("Error saving the game state: " + ioe.getMessage());
         }
  }
  /**
   * The original tile size in pixels (before scaling).
   */
  final int tileSizeOriginal = 32;
  /**
   * The scale factor for resizing the tiles.
   */
  final int scale = 2;
  /**
   * The scaled tile size in pixels, calculated by multiplying the original tile size
   * by the scale factor.
   */
  public final int tileSize = tileSizeOriginal * scale;
  /**
   * The maximum number of columns that can be displayed on the screen.
   */
  public final int maxScreenColumn = 20;
  /**
   * The maximum number of rows that can be displayed on the screen.
   */
  public final int maxScreenRow = 12;
  /**
   * The screen width in pixels, based on the tile size and the maximum number of columns.
   */
  public final int screenWidth = tileSize * maxScreenColumn;
  /**
   * The screen height in pixels, based on the tile size and the maximum number of rows.
   */
  public final int screenHeight = tileSize * maxScreenRow;
  
  /**
   * The maximum number of columns in the game world.
   */
  public final int maxWorldCol = 30;
  /**
   * The maximum number of rows in the game world.
   */
  public final int maxWorldRow = 30;
  /**
   * The world width in pixels, based on the tile size and the maximum number of columns in the world.
   */
  public final int worldWidth = tileSize * maxWorldCol;
  /**
   * The world height in pixels, based on the tile size and the maximum number of rows in the world.
   */
  public final int worldHeight = tileSize * maxWorldRow;
  /**
   * Frames per second (FPS) for the game loop.
   */
  int FPS = 60;
  /**
   * responsible for managing and drawing tiles in the game world.
   */
  TileManager tileM = new TileManager(this);
  /**
   * used to manage player input via the keyboard.
   */
  KeyHandler keyH = new KeyHandler();
  /**
   * The game thread, responsible for managing the game's timing and running the game loop.
   */
  Thread gameThread; // time. something you can start and stop. Keeps program running.
  /**
   * used for detecting collisions in the game world.
   */
  public CollisionChecker cChecker = new CollisionChecker(this);
  /**
   *  used for setting up and placing assets (objects) in the game world.
   */
  public AssetSetter aSetter = new AssetSetter(this);
  /**
   * representing the player-controlled character in the game.
   */
  public Player player = new Player(this, keyH);
  
  // This is where you create the object slots to put objects into our game
  /**
   * An array of {@code SuperObject} instances, representing objects placed in the game world.
   * The array can hold up to 10 objects.
   */
  public SuperObject obj[] = new SuperObject[10];
  
  /**
   * Initializes the game by setting up game objects and assets.
   * This method is called during the game's setup phase.
   */
  public void setupGame(){
    aSetter.setObject();
    
  }
  /**
   * Starts the game thread, which runs the game loop.
   */
  public void startGameThread(){
    gameThread = new Thread(this);
    gameThread.start();
  }
  
  /**
   * Used Variable Time Step Loop
   */
  public void run(){
    
    double drawInterval = 1000000000/FPS;
    double delta = 0;
    long lastTime = System.nanoTime();
    long currentTime;
    
    
    // Game Loop. Core of our game
    while (gameThread != null){
      
      currentTime = System.nanoTime();
      delta += (currentTime - lastTime) / drawInterval;
      lastTime = currentTime;
      
      if (delta >= 1){
        update(); // update information such as character position.
        repaint(); // draws the screen with the updated information.
        delta--;
      }
    }
  }
  
  /**
   * Updates the game state. This includes updating the player and other game entities.
   */
  public void update(){
    player.update();
    
    
  }
  
  
  /**
   * Paints the game screen by drawing all the game elements (tiles, objects, player).
   *
   * @param g The {@code Graphics} object used to draw on the screen.
   */
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    
    Graphics2D g2 = (Graphics2D) g;
    
    
    
    tileM.draw(g2);
    
    for(int i = 0; i<obj.length; i ++){
      if(obj[i] != null){
        obj[i].draw(g2,this);
      }
    }
    player.draw(g2);
    
    
  }
  
  
  /**
   * Constructs the GameLayout and sets up the preferred size, background color,
   * and other configurations for the game window.
   */
  public GameLayout(){
    this.setPreferredSize(new Dimension(screenWidth, screenHeight)); 
    this.setBackground(Color.black);
    this.setDoubleBuffered(true);
    this.addKeyListener(keyH);
    this.setFocusable(true);
    
  }
  
  
  
}


/**
 * The Edge class represents a directed edge from one location (source) to another (destination).
 * This class is used in the GameLayout to define the connections between locations.
 */
class Edge {
  private String source;
  private String dest;
  
  /**
   * Constructs an Edge object that represents a directed connection from the source location to the destination.
   *
   * @param source The source location.
   * @param dest The destination location.
   */
  public Edge(String source, String dest) {
    this.source = source;
    this.dest = dest;
  }
  
  /**
   * Retrieves the source location of the edge.
   *
   * @return The source location.
   */
  public String getSource() {
    return source;
  }
  
  /**
   * Retrieves the destination location of the edge.
   *
   * @return The destination location.
   */
  public String getDest() {
    return dest;
  }
  
  /**
   * Checks if this edge is equal to another edge based on source and destination.
   *
   * @param obj The object to compare with this edge.
   * @return true if the source and destination are the same, false otherwise.
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    Edge edge = (Edge) obj;
    return source.equals(edge.source) && dest.equals(edge.dest);
  }
  
  /**
   * Computes the hash code for the edge based on the source and destination.
   *
   * @return The hash code of the edge.
   */
  @Override
  public int hashCode() {
    return Objects.hash(source, dest);
  }
}
