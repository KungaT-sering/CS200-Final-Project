package main;

import java.io.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * The TileManager class handles the management of tiles within the game world.
 * It is responsible for loading and rendering the tiles, as well as checking tile collisions
 * and managing the map layout for different stages.
 * @author Reagan Hennen and Kunga Tsering
 */
public class TileManager{
  /**
   * Reference to the GameLayout object for accessing game-related data.
   */
  GameLayout gp;
  /**
   * Array that holds all available tile objects for the game.
   */
  public Tile[] tile;
  
  /**
   * 2D array representing the map's tile IDs.
   * Each element in the array corresponds to a specific tile type in the world.
   */
  public int mapTileNum[][];
  
  /**
   * The current stage of the game.
   * Determines which map to load for rendering.
   */
  static int stage;
  
  /**
   * Constructor that initializes the TileManager with the provided GameLayout.
   * It also initializes the tiles and loads the map for the current stage.
   *
   * @param gp The GameLayout object that contains game-specific configurations.
   */
  public TileManager(GameLayout gp){
    this.gp = gp; 
    tile = new Tile[49];
    mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
    getTileImage();
    
    // S is 0
    // E1 is 1
    // E2 is 2
    // H1 is 3
    // E3 is 4
    // H2 is 5
    // H3 is 6
    // D is 7
    // E4 is 8
    // B is 9
    
    stage = 0;
    loadMapForStage(stage);
  }
  
  /**
   * Loads the images for all the tiles used in the game.
   * This method associates each tile index with a specific image and sets up tile properties like collision.
   */
  public void getTileImage(){
    try{
      tile[0] = new Tile();
      tile[0].image = ImageIO.read(getClass().getResourceAsStream("/assets/Wood.png"));
      
      tile[1] = new Tile();
      tile[1].image = ImageIO.read(getClass().getResourceAsStream("/assets/Window.png"));
      
      tile[2] = new Tile();
      tile[2].image = ImageIO.read(getClass().getResourceAsStream("/assets/Wall.png"));
      tile[2].collision = true;
      
      tile[3] = new Tile();
      tile[3].image = ImageIO.read(getClass().getResourceAsStream("/assets/leftCarpet.png"));
      
      tile[4] = new Tile();
      tile[4].image = ImageIO.read(getClass().getResourceAsStream("/assets/rightCarpet.png"));
      
      tile[5] = new Tile();
      tile[5].image = ImageIO.read(getClass().getResourceAsStream("/assets/grandpa.png"));
      tile[5].collision = true;
      
      tile[6] = new Tile();
      tile[6].image = ImageIO.read(getClass().getResourceAsStream("/assets/bush.png"));
      tile[6].collision = true;
      
      tile[7] = new Tile();
      tile[7].image = ImageIO.read(getClass().getResourceAsStream("/assets/bushwithsnow.png"));
      tile[7].collision = true;
      
      tile[8] = new Tile();
      tile[8].image = ImageIO.read(getClass().getResourceAsStream("/assets/treeTop.png"));
      tile[8].collision = true;
      
      tile[9] = new Tile();
      tile[9].image = ImageIO.read(getClass().getResourceAsStream("/assets/treeTopWithSnow.png"));
      tile[9].collision = true;
      
      tile[10] = new Tile();
      tile[10].image = ImageIO.read(getClass().getResourceAsStream("/assets/treeBottom.png"));
      tile[10].collision = true;
      
      tile[11] = new Tile();
      tile[11].image = ImageIO.read(getClass().getResourceAsStream("/assets/treeBottomWithSnow.png"));
      tile[11].collision = true;
      
      tile[12] = new Tile();
      tile[12].image = ImageIO.read(getClass().getResourceAsStream("/assets/grass.png"));
      
      tile[13] = new Tile();
      tile[13].image = ImageIO.read(getClass().getResourceAsStream("/assets/Path.png"));
      
      tile[14] = new Tile();
      tile[14].image = ImageIO.read(getClass().getResourceAsStream("/assets/redflower.png"));
      
      tile[15] = new Tile();
      tile[15].image = ImageIO.read(getClass().getResourceAsStream("/assets/blueflower.png"));
      
      tile[16] = new Tile();
      tile[16].image = ImageIO.read(getClass().getResourceAsStream("/assets/door.png"));
      tile[16].collision = true;
      
      tile[17] = new Tile();
      tile[17].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof1.png"));
      tile[17].collision = true;
      
      tile[18] = new Tile();
      tile[18].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof2.png"));
      tile[18].collision = true;
      
      tile[19] = new Tile();
      tile[19].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof3.png"));
      tile[19].collision = true;
      
      tile[20] = new Tile();
      tile[20].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof4.png"));
      tile[20].collision = true;
      
      tile[21] = new Tile();
      tile[21].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof5.png"));
      tile[21].collision = true;
      
      tile[22] = new Tile();
      tile[22].image = ImageIO.read(getClass().getResourceAsStream("/assets/roof6.png"));
      tile[22].collision = true;
      
      tile[23] = new Tile();
      tile[23].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow1.png"));
      
      tile[24] = new Tile();
      tile[24].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow2.png"));
      
      tile[25] = new Tile();
      tile[25].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow3.png"));
      
      tile[26] = new Tile();
      tile[26].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow4.png"));
      
      tile[27] = new Tile();
      tile[27].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow5.png"));
      
      tile[28] = new Tile();
      tile[28].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow6.png"));
      
      tile[29] = new Tile();
      tile[29].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow7.png"));
      
      tile[30] = new Tile();
      tile[30].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow8.png"));
      
      tile[31] = new Tile();
      tile[31].image = ImageIO.read(getClass().getResourceAsStream("/assets/snow9.png"));
      
      tile[32] = new Tile(); // MIGHT CHANGE to have collision or not
      tile[32].image = ImageIO.read(getClass().getResourceAsStream("/assets/BadEnemy.png"));
      tile[32].collision = false;
      
      tile[33] = new Tile();
      tile[33].image = ImageIO.read(getClass().getResourceAsStream("/assets/FinalBoss.png"));
      tile[33].collision = true;
      
      tile[34] = new Tile();
      tile[34].image = ImageIO.read(getClass().getResourceAsStream("/assets/Ice.png"));
      // idk if should have collision or not
      tile[34].collision = true;
      
      // I do not think I even need this.
      tile[35] = new Tile();
      tile[35].image = ImageIO.read(getClass().getResourceAsStream("/assets/Pokeball.png"));
      
      // i do not think I even need this.
      tile[36] = new Tile();
      tile[36].image = ImageIO.read(getClass().getResourceAsStream("/assets/Radish.png"));
      
      // Water tiles
      tile[37] = new Tile();
      tile[37].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterBottomLeft.png"));
      tile[37].collision = true;
      
      tile[38] = new Tile();
      tile[38].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterBottomRight.png"));
      tile[38].collision = true;
      
      tile[39] = new Tile();
      tile[39].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterBottomTile.png"));
      tile[39].collision = true;
      
      tile[40] = new Tile();
      tile[40].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterLeftTile.png"));
      tile[40].collision = true;
      
      tile[41] = new Tile();
      tile[41].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterRightTile.png"));
      tile[41].collision = true;
      
      tile[42] = new Tile();
      tile[42].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterTopLeft.png"));
      tile[42].collision = true;
      
      tile[43] = new Tile();
      tile[43].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterTopRight.png"));
      tile[43].collision = true;
      
      tile[44] = new Tile();
      tile[44].image = ImageIO.read(getClass().getResourceAsStream("/assets/WaterTopTile.png"));
      tile[44].collision = true;
      
      tile[45] = new Tile();
      tile[45].image = ImageIO.read(getClass().getResourceAsStream("/assets/Water.png"));
      tile[45].collision = true;
      
      // Might change later
      tile[46] = new Tile();
      tile[46].image = ImageIO.read(getClass().getResourceAsStream("/assets/Soup.png"));
      
      tile[47] = new Tile();
      tile[47].image = ImageIO.read(getClass().getResourceAsStream("/assets/black.png"));
      tile[47].collision = true;
      
      tile[48] = new Tile();
      tile[48].image = ImageIO.read(getClass().getResourceAsStream("/assets/JumpTile.png"));
      tile[48].collision = false;
      tile[48].switchMap = true;
      
    } catch (IOException e){
      e.printStackTrace();
    }
  }
  
  
  /**
   * Loads the map for the given stage number.
   * It sets up the mapTileNum array based on the stage number.
   *
   * @param stage The stage number for which the map should be loaded.
   */
  public void loadMapForStage(int stage) {
    String mapPath = "";
    switch (stage) {
      case 0:
        mapPath = "/S";  
        break;
      case 1:
        mapPath = "/E1"; 
        break;
      case 2:
        mapPath = "/E2"; 
        break;
      case 3:
        mapPath = "/H1"; 
        break;
      case 4:
        mapPath = "/E3"; 
        break;
      case 5:
        mapPath = "/H2"; 
        break;
      case 6:
        mapPath = "/H3"; 
        break;
      case 7:
        mapPath = "/D"; 
        break;
      case 8:
        mapPath = "/E4";
        break;
      case 9:
        mapPath = "/B"; 
        break;
      default:
        mapPath = "/S";  // Default to the first map if stage is undefined
        break;
    }
    loadMap(mapPath); // Load the map based on the current stage
  }
  
  /**
   * Loads the map data from a file into the mapTileNum array.
   * The map is represented as a grid of tile IDs, where each tile corresponds
   * to a specific type of tile in the game world.
   *
   * @param filePath The path to the map file, relative to the classpath. This file should contain
   *                 a grid of tile IDs separated by spaces, with each row representing a row of tiles
   *                 in the game world.
   */
  public void loadMap(String filePath){
    try {
      InputStream is = getClass().getResourceAsStream(filePath);
      BufferedReader br = new BufferedReader(new InputStreamReader(is));
      
      int col = 0;
      int row = 0;
      
      while (col < gp.maxWorldCol && row < gp.maxWorldRow){
        String line = br.readLine(); 
        while (col < gp.maxWorldCol){
          String numbers[] = line.split(" "); 
          int num = Integer.parseInt(numbers[col]);
          mapTileNum[col][row] = num;
          col++;
        }
        if (col == gp.maxWorldCol){
          col = 0;
          row++;
        }
      }
      br.close();
      
    } catch (Exception e){
      e.printStackTrace();
    }
  }
  
  /**
   * Retrieves the tile ID from the mapTileNum array at the given (x, y) coordinates.
   * The map is represented by a 2D array, where each element corresponds to a specific
   * tile ID in the game world.
   *
   * @param x The x-coordinate (column index) of the tile in the map.
   * @param y The y-coordinate (row index) of the tile in the map.
   * @return The tile ID at the specified coordinates.
   */
  public int getTileId(int x, int y){
    return mapTileNum[y][x]; 
  }
  
  /**
   * Renders the map based on the current state of the game and its tiles.
   * It loops through all the columns and rows to draw the tiles at their respective positions.
   */
  public void draw(Graphics2D g2){
    
    int col = 0;
    int row = 0;
  
    while (col < gp.maxWorldCol && row < gp.maxWorldRow){
      
      int tileNum = mapTileNum[col][row];
      
      int worldX = col * gp.tileSize;
      int worldY = row * gp.tileSize;
      int screenX = worldX - gp.player.x + gp.player.screenX;
      int screenY = worldY - gp.player.y + gp.player.screenY;

      if (worldX + gp.tileSize > gp.player.x - gp.player.screenX && worldX - gp.tileSize < gp.player.x + gp.player.screenX && worldY + gp.tileSize > gp.player.y - gp.player.screenY && worldY - gp.tileSize < gp.player.y + gp.player.screenY){
        g2.drawImage(tile[tileNum].image, screenX, screenY, gp.tileSize, gp.tileSize, null);
      }
      
      col++;
      
      if (col == gp.maxWorldCol){
        col = 0;
        row++;
      }
    }
    
  }
  
}