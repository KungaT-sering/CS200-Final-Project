package main;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * The KeyHandler class implements the KeyListener interface and is responsible 
 * for handling key events during gameplay. It tracks whether specific keys (W, A, S, D) are pressed 
 * or released to control the movement of the player or other game entities.
 * @author Reagan Hennen and Kunga Tsering
 */
public class KeyHandler implements KeyListener{
  /**
   * A boolean flag indicating if the up, down, left, or right is is pressed
   */
  public boolean upPressed, downPressed, leftPressed, rightPressed;
  
  /**
   * Called when a key is typed (character input).
   * This method is empty as the game does not require character input handling.
   * 
   * @param e The key event.
   */
  public void keyTyped(KeyEvent e){
  }
  /**
   * Called when a key is pressed down.
   * Updates the state of the direction-related boolean flags (upPressed, downPressed, 
   * leftPressed, rightPressed) based on the key pressed.
   * 
   * @param e The key event.
   */
  public void keyPressed(KeyEvent e){
    int code = e.getKeyCode();
    
    if (code == KeyEvent.VK_W){
      upPressed = true;
    }
    if (code == KeyEvent.VK_S){
      downPressed = true;
    }
    if (code == KeyEvent.VK_A){
      leftPressed = true;
    }
    if (code == KeyEvent.VK_D){
      rightPressed = true;
    } 
    
  }
  /**
   * Called when a key is released.
   * Resets the state of the direction-related boolean flags (upPressed, downPressed, 
   * leftPressed, rightPressed) when the corresponding key is released.
   * 
   * @param e The key event.
   */
  public void keyReleased(KeyEvent e){
    int code = e.getKeyCode();
    
    if (code == KeyEvent.VK_W){
      upPressed = false;
    }
    if (code == KeyEvent.VK_S){
      downPressed = false;
    }
    if (code == KeyEvent.VK_A){
      leftPressed = false;
    }
    if (code == KeyEvent.VK_D){
      rightPressed = false;
    } 
  }
  
}