package main;
import object.*;
/**
 * The AssetSetter class is responsible for managing and assigning objects to specific locations
 * in the game world, depending on the current game stage.
 * The objects include things like enemies, items, and other entities in the game.
 * @author Reagan Hennen and Kunga Tsering
 */
public class AssetSetter{
  /**
   * Reference to the GameLayout instance that holds the game objects
   */
  GameLayout gl;
  /**
   * Constructor that initializes the AssetSetter with the provided GameLayout.
   * 
   * @param gl The GameLayout instance that holds the game's objects.
   */
  public AssetSetter(GameLayout gl){
    this.gl = gl;
    
  }
  /**
   * Sets up the game objects based on the current stage in the game. This method clears any existing
   * objects and assigns new ones to specific coordinates for each stage of the game.
   * 
   * For each stage, different objects are placed in the game world, such as enemies, items (like radishes, soup, etc.),
   * and NPCs (like Grandpa). The coordinates of each object are determined based on the stage.
   */
  public void setObject(){
    
    for (int i = 0; i < gl.obj.length; i++){
      gl.obj[i] = null;
    }
    
    if (TileManager.stage == 0){
      gl.obj[0] = new OBJ_Radish();
      gl.obj[0].worldX = 7 * gl.tileSize;
      gl.obj[0].worldY =  9 * gl.tileSize;
      
      gl.obj[1] = new OBJ_Grandpa();
      gl.obj[1].worldX = 17 * gl.tileSize;
      gl.obj[1].worldY = 5 * gl.tileSize;
      
    } else if (TileManager.stage == 1){
      
      gl.obj[0] = new OBJ_Enemy();
      gl.obj[0].worldX = 12 * gl.tileSize;
      gl.obj[0].worldY = 6 * gl.tileSize;
      
    } else if (TileManager.stage == 2){
      // E2
      gl.obj[0] = new OBJ_Enemy();
      gl.obj[0].worldX = 5 * gl.tileSize;
      gl.obj[0].worldY = 5 * gl.tileSize;
      
    } else if (TileManager.stage == 3){
      
      gl.obj[0] = new OBJ_Radish();
      gl.obj[0].worldX = 5 * gl.tileSize;
      gl.obj[0].worldY = 5 * gl.tileSize;
      
      
    } else if (TileManager.stage == 4){
      //bridge so nothing
      
    } else if (TileManager.stage == 5){
      // cold area add nothing
      
    } else if (TileManager.stage == 7){
      gl.obj[0] = new OBJ_Soup();
      gl.obj[0].worldX = 5 * gl.tileSize;
      gl.obj[0].worldY = 3 * gl.tileSize;
      
    } else if (TileManager.stage == 6){
      gl.obj[0] = new OBJ_PokeBall();
      gl.obj[0].worldX = 7 * gl.tileSize;
      gl.obj[0].worldY = 4 * gl.tileSize;
      
    } else if (TileManager.stage == 8){
      gl.obj[0] = new OBJ_Enemy();
      gl.obj[0].worldX = 7 * gl.tileSize;
      gl.obj[0].worldY = 6 * gl.tileSize;
      
    } else if (TileManager.stage == 9){
      gl.obj[0] = new OBJ_FinalBoss();
      gl.obj[0].worldX = 4 * gl.tileSize;
      gl.obj[0].worldY = 3 * gl.tileSize;
      
      gl.obj[1] = new OBJ_Soup();
      gl.obj[1].worldX = 5 * gl.tileSize;
      gl.obj[1].worldY = 3 * gl.tileSize;
      
    }
    
    
    
  }
  
}