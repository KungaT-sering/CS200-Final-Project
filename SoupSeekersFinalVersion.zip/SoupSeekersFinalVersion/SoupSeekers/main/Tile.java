package main;

import java.awt.image.BufferedImage;

/**
 * The Tile class represents a single tile in the game world.
 * @author Reagan Hennen and Kunga Tsering
 */
public class Tile {

    /**
     * The BufferedImage that represents the visual appearance of this tile.
     */
    public BufferedImage image;

    /**
     * A boolean flag that indicates whether the tile causes a collision when the player interacts with it.
     * If true, the player will be blocked by this tile. If false, the player can walk over it.
     */
    public boolean collision = false;

    /**
     * A boolean flag that indicates whether the tile triggers a map switch when interacted with.
     * If true, the tile causes the game to switch to another map.
     * If false, the tile does not trigger any map change.
     */
    public boolean switchMap = false;

}
