package main;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * CS 200 Final Project driver
 * The Driver class is the entry point of the game. It provides an interactive menu for the player
 * to interact with the game world, including actions like listing locations, moving between locations, 
 * viewing properties of locations, and saving/loading game state.
 * @author Reagan Hennen and Kunga Tsering
 */
public class Driver {
  
  /**
   * The class-level variables for the game, including the game layout, the current location of the player, 
   * and the game panel where the game is rendered.
   */
  private static GameLayout game;
  
  /**
   * The current location of the player or character in the game world.
   * This string stores the name or identifier of the current location or level.
   * It could represent a specific area or map in the game, like a town, dungeon, or outdoor area.
   */
  private static String currentLocation;
  
  /**
   * The game panel where the game's graphics are rendered.
   * This variable represents the main panel that is responsible for displaying the game's visual content.
   * It serves as the user interface for rendering the game world, entities, and other components.
   */
  private static GameLayout gamePanel;
  
  /**
   * The main method that initializes the game, displays the menu, and processes user input.
   * It is the entry point to run the game.
   * 
   * @param args command-line arguments (not used)
   */
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    String connectionsFile = "connections";
    String descriptionsFile = "descriptions";
    
    game = new GameLayout(connectionsFile, descriptionsFile);
    
    currentLocation = "S";  // Starting location
    
    JFrame window = new JFrame(); 
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setResizable(false);
    window.setTitle("Start! Go find soup for your grandpa! Travel by Green Circles!");
    
    gamePanel = new GameLayout();
    
    CollisionChecker collisionChecker = new CollisionChecker(gamePanel);
    
    gamePanel.addKeyListener(gamePanel.keyH);
    
    window.add(gamePanel);
    gamePanel.requestFocusInWindow();
    window.pack();
    
    JButton traverseButton = new JButton("Choose Next World");
    JButton traverseButton2 = new JButton("Choose Next World");
    
    JButton toE3 = new JButton("Go to Next World");
    JButton toH2 = new JButton("Go to Next World");
    JButton toD = new JButton("Go to Next World");
    JButton toB = new JButton("Go to Next World");
    
    JButton all = new JButton("All locations");
    all.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        all.setText(listLocations());
        gamePanel.requestFocusInWindow();
      }
    });
    
    JButton prop = new JButton("List Current Location's Properties");
    prop.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        prop.setText(listCurrentLocationProperties());
        gamePanel.requestFocusInWindow();
      }
    });
    
    JButton conn = new JButton("List Current Location's Connections");
    conn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        conn.setText(listConnectionsForCurrentLocation());
        gamePanel.requestFocusInWindow();
      }
    });
    
    JButton save = new JButton("Save game");
    save.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        saveGameState();
        gamePanel.requestFocusInWindow();
      }
    });
    
    JButton e = new JButton("Go to next world");
    e.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        
        if (collisionChecker.isOnJumpingTile()){
//          System.out.println("So it does work");
        // Move to the next world (stage increment)
        gamePanel.requestFocusInWindow();
        TileManager.stage = 1;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
        
        AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
        
        gamePanel.player.x = gamePanel.tileSize * 4;
        gamePanel.player.y = gamePanel.tileSize * 20;
        gamePanel.requestFocusInWindow();
        gamePanel.repaint();  // Repaint the frame after advancing to the next stage
        
        // Change the window title and current location
        window.setTitle("E1");
        currentLocation = "E1";
        
        // Make the button 'e' disappear after it's clicked
        e.setVisible(false);
        
        // Show the new button to allow choosing the next world
        traverseButton.setVisible(true);
        
        // Set up the other buttons
        prop.setText("List Current Location's Properties");
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        
        conn.setText("List Current Location's Connections");
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
       
        } else {
         gamePanel.requestFocusInWindow();
        }
      
    }
      
    });
    
    // Action listener for the 'traverseButton' to choose the next world
    traverseButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        // Ask the player for the next world option (H1 or E2)
        
       if (collisionChecker.isOnJumpingTile()){
        
        String[] options = {"Left", "Right"};
        String worldChoice = (String) JOptionPane.showInputDialog(
                                                                  window,
                                                                  "Choose which direction you would like to go:",
                                                                  "Direction Choice",
                                                                  JOptionPane.QUESTION_MESSAGE,
                                                                  null,
                                                                  options,
                                                                  options[0] 
                                                                 );
        int randomInt = (int) (Math.random() * 2);
        if (worldChoice != null) {
          if (randomInt == 0) {
            currentLocation = "H1";
            window.setTitle("H1");
            TileManager.stage = 3;
            gamePanel.tileM.loadMapForStage(TileManager.stage);
                    AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            gamePanel.requestFocusInWindow();
          } else if (randomInt == 1) {
            currentLocation = "E2";
            window.setTitle("E2");
               TileManager.stage = 2;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
                AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            gamePanel.requestFocusInWindow();
          }
          gamePanel.repaint();
          traverseButton.setVisible(false);
          toE3.setVisible(true);
          
          prop.setText("List Current Location's Properties");
          prop.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              prop.setText(listCurrentLocationProperties());
              gamePanel.requestFocusInWindow();
            }
          });
          
          conn.setText("List Current Location's Connections");
          conn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              conn.setText(listConnectionsForCurrentLocation());
              gamePanel.requestFocusInWindow();
            }
          });
        }
        
       } else {
        gamePanel.requestFocusInWindow();
       }
      }
      
      
      
      
    });
    
    traverseButton2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        
        if (collisionChecker.isOnJumpingTile()){
        String[] options = {"Left", "Right"};
        String worldChoice = (String) JOptionPane.showInputDialog(
                                                                  window,
                                                                  "Choose which direction you would like to go:",
                                                                  "Direction Choice",
                                                                  JOptionPane.QUESTION_MESSAGE,
                                                                  null,
                                                                  options,
                                                                  options[0] 
                                                                 );
        int randomInt = (int) (Math.random() * 2);
        
        if (worldChoice != null) {
          if (randomInt == 0) {
            currentLocation = "H3";
            window.setTitle("H3");
            

            TileManager.stage = 6;
            gamePanel.tileM.loadMapForStage(TileManager.stage);
                    AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
            
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            gamePanel.requestFocusInWindow();
            gamePanel.repaint();
            
            traverseButton2.setVisible(false);
            toD.setVisible(true);
          } else if (randomInt== 1) {
            currentLocation = "E4";
            window.setTitle("E4");
            TileManager.stage = 8;
            gamePanel.tileM.loadMapForStage(TileManager.stage);
                    AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            gamePanel.requestFocusInWindow();
            gamePanel.repaint();
            traverseButton2.setVisible(false);
            toB.setVisible(true);
          }
          
          prop.setText("List Current Location's Properties");
          prop.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              prop.setText(listCurrentLocationProperties());
              gamePanel.requestFocusInWindow();
            }
          });
          
          conn.setText("List Current Location's Connections");
          conn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              conn.setText(listConnectionsForCurrentLocation());
              gamePanel.requestFocusInWindow();
            }
          });
        }
        } else {
          gamePanel.requestFocusInWindow();
        }
      
    }
      
    });
    
    JButton searchButton = new JButton("Search Property");
    JTextField searchField = new JTextField(20);
    searchButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        String property = searchField.getText();
        if (!property.isEmpty()) {
          String result = searchForProperty(property);
          JOptionPane.showMessageDialog(window, "Search result for property: " + result);
        } else {
          JOptionPane.showMessageDialog(window, "Please enter a property to search for.");
        }
        gamePanel.requestFocusInWindow();
      }
    });
    
    toE3.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        if (collisionChecker.isOnJumpingTile()){
        
        TileManager.stage=4;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
                AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
        gamePanel.player.x = gamePanel.tileSize * 8;
        gamePanel.player.y = gamePanel.tileSize * 28;
        gamePanel.requestFocusInWindow();
        gamePanel.repaint();  
        window.setTitle("E3");
        currentLocation = "E3";
        toE3.setVisible(false);
        toH2.setVisible(true);
        prop.setText("List Current Location's Properties");
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        conn.setText("List Current Location's Connections");
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
        
        } else {
          gamePanel.requestFocusInWindow();
        }
        
      }
    });
    
    toH2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        // Move to the next world (stage increment)
        
        if (collisionChecker.isOnJumpingTile()){
        
        
        TileManager.stage=5;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
                AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
        gamePanel.player.x = gamePanel.tileSize * 13;
        gamePanel.player.y = gamePanel.tileSize * 24;
        gamePanel.requestFocusInWindow();
        gamePanel.repaint();  // Repaint the frame after advancing to the next stage
        
        // Change the window title and current location
        window.setTitle("H2");
        currentLocation = "H2";
        
        // Make the button 'e' disappear after it's clicked
        toH2.setVisible(false);
        
        // Show the new button to allow choosing the next world
        traverseButton2.setVisible(true);
        
        // Set up the other buttons
        prop.setText("List Current Location's Properties");
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        
        conn.setText("List Current Location's Connections");
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
        } else {
          gamePanel.requestFocusInWindow();
        }
      
      }
      
      
    });
    
    
    toB.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        
        if (collisionChecker.isOnJumpingTile()){
        
        // Move to the next world (stage increment)
        TileManager.stage=9;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
        AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        gamePanel.requestFocusInWindow();
        gamePanel.repaint();  // Repaint the frame after advancing to the next stage
        
        // Change the window title and current location
        window.setTitle("B - The Good Ending! Congrats, you win! You found the soup!");
        currentLocation = "B";
        
        // Make the button 'e' disappear after it's clicked
        toB.setVisible(false);
        
        // Show the new button to allow choosing the next world
        //traverseButton2.setVisible(true);
        
        // Set up the other buttons
        prop.setText("List Current Location's Properties");
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        
        conn.setText("List Current Location's Connections");
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
        
        } else {
         gamePanel.requestFocusInWindow(); 
        }
        
      }
      
      
      
      
    });
    
    
    
    
    toD.addActionListener(new ActionListener() {
      
      
      public void actionPerformed(ActionEvent ev) {
        // Move to the next world (stage increment)
        
        if (collisionChecker.isOnJumpingTile()){
        
        TileManager.stage = 7;
        gamePanel.tileM.loadMapForStage(TileManager.stage);
                AssetSetter assetSetter = new AssetSetter(gamePanel);
        assetSetter.setObject();
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        gamePanel.requestFocusInWindow();
        gamePanel.repaint();  // Repaint the frame after advancing to the next stage
        
        // Change the window title and current location
        window.setTitle("D - You Lost! No Soup for you!!!");
        currentLocation = "D";
        
        // Make the button 'e' disappear after it's clicked
        toD.setVisible(false);
        
        // Show the new button to allow choosing the next world
        //traverseButton2.setVisible(true);
        
        // Set up the other buttons
        prop.setText("List Current Location's Properties");
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        
        conn.setText("List Current Location's Connections");
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
        
        } else {
          gamePanel.requestFocusInWindow();
        }
      }
      
      
      
    });
    
    
    
    
    JButton load = new JButton("Load previous game state");
    load.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        loadGameState();
                   AssetSetter assetSetter = new AssetSetter(gamePanel);
            assetSetter.setObject();
        switch (currentLocation) {
          case "E1":
            
            traverseButton.setVisible(true);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("E1");
            gamePanel.tileM.loadMapForStage(1);


            gamePanel.player.x = gamePanel.tileSize * 4;
            gamePanel.player.y = gamePanel.tileSize * 20;
            break;
            
          case "H1":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(true);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("H1");
            gamePanel.tileM.loadMapForStage(3);


            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          case "E2":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(true);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("E2");
            gamePanel.tileM.loadMapForStage(2);
 

            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          case "E3":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(true);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("E3");
            gamePanel.tileM.loadMapForStage(4);

            gamePanel.player.x = gamePanel.tileSize * 8;
            gamePanel.player.y = gamePanel.tileSize * 28;
            break;
            
          case "H2":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(true);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("H2");
            gamePanel.tileM.loadMapForStage(5);
            


            gamePanel.player.x = gamePanel.tileSize * 13;
            gamePanel.player.y = gamePanel.tileSize * 24;
            break;
            
          case "H3":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(true);
            e.setVisible(false);
            
            window.setTitle("H3");
            gamePanel.tileM.loadMapForStage(6);

            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          case "E4":
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(true);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("E4");
            gamePanel.tileM.loadMapForStage(8);
            

   
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          case "B":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);
            
            window.setTitle("B, Congrats, you win! You found the soup!");
            gamePanel.tileM.loadMapForStage(9);

            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          case "D":
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(false);               
            
            window.setTitle("D, Dead end no soup for you! You Lose");
            gamePanel.tileM.loadMapForStage(7);
  
            gamePanel.player.x = gamePanel.tileSize * 5;
            gamePanel.player.y = gamePanel.tileSize * 9;
            break;
            
          default:
            // System.out.println("Unknown location: " + currentLocation);
            currentLocation = "S"; // Reset to start if location is unknown
            
            traverseButton.setVisible(false);
            traverseButton2.setVisible(false);
            toE3.setVisible(false);
            toH2.setVisible(false);
            toB.setVisible(false);
            toD.setVisible(false);
            e.setVisible(true);
            
            window.setTitle("Start");
            gamePanel.tileM.loadMapForStage(0); // Load the starting map

            
            gamePanel.player.x = gamePanel.tileSize * 100;
            gamePanel.player.y = gamePanel.tileSize * 100;
            break;
        }
        
 
        
        // Repaint the game panel to reflect the changes
        gamePanel.requestFocusInWindow();    
        gamePanel.repaint();
        // Optionally, set up other buttons for the loaded location
        prop.setText("List Current Location's Properties");
        conn.setText("List Current Location's Connections");
        
        prop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            prop.setText(listCurrentLocationProperties());
            gamePanel.requestFocusInWindow();
          }
        });
        
        conn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            conn.setText(listConnectionsForCurrentLocation());
            gamePanel.requestFocusInWindow();
          }
        });
      }
    });
    
    
    
    
    
    // Create a panel for the buttons
    JPanel topPanel = new JPanel();
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
    
    topPanel.add(all);
    topPanel.add(prop);
    topPanel.add(conn);
    topPanel.add(searchButton);
    topPanel.add(searchField);
    topPanel.add(e);
    topPanel.add(traverseButton); 
    topPanel.add(traverseButton2);
    topPanel.add(toE3);
    topPanel.add(toH2);
    topPanel.add(toB);
    topPanel.add(toD);
    topPanel.add(save);
    topPanel.add(load);
    
    
    traverseButton.setVisible(false);
    traverseButton2.setVisible(false);
    toE3.setVisible(false);
    toH2.setVisible(false);
    toB.setVisible(false);
    toD.setVisible(false);
    
    
    
    window.add(topPanel, BorderLayout.NORTH);
    window.pack();
    window.setLocationRelativeTo(null);
    gamePanel.requestFocusInWindow();
    window.setVisible(true);
    gamePanel.setupGame();
    gamePanel.startGameThread();
  }
  
  
  /**
   * Lists all locations available in the game.
   * This method iterates over all locations and prints each one to the console.
   */
  private static String listLocations() {
    StringBuilder locationsList = new StringBuilder("Locations: ");
    Iterator<String> locations = game.getLocationIterator();
    if (locations.hasNext()) {
      locationsList.append(locations.next()); 
    }
    while (locations.hasNext()) {
      locationsList.append(", ").append(locations.next());
    }
    return locationsList.toString();
  }
  
  
  
  /**
   * Lists the properties of the current location, including its description.
   * If a description is available for the current location, it will be displayed.
   */
  private static String listCurrentLocationProperties() {
    StringBuilder result = new StringBuilder();
    result.append("Current location: ").append(currentLocation).append("\n"+" ");
    
    LocationDescription description = game.getDescription(currentLocation);
    if (description != null) {
      result.append("Description: ").append(description.getDescription()).append("\n");
    } else {
      result.append("No description available.\n");
    }
    
    return result.toString();
  }
  
  
  
  /**
   * Lists all locations that are connected to the current location.
   * This method displays all the neighboring locations the player can travel to from the current location.
   */
  private static String listConnectionsForCurrentLocation() {
    StringBuilder result = new StringBuilder("Connections from " + currentLocation + ": ");
    
    Iterator<String> connections = game.getConnectionsIterator(currentLocation);
    if (connections != null && connections.hasNext()) {
      while (connections.hasNext()) {
        result.append(connections.next());
        if (connections.hasNext()) {
          result.append(", ");  // Add a comma between connections
        }
      }
    } else {
      result.append("No connections found.");
    }
    
    return result.toString();
  }
  
  /**
   * Moves the player to a new location. The new location must be connected to the current location.
   * If the move is valid (i.e., the new location is connected), the current location is updated.
   * 
   * @param scanner Scanner object to read user input
   */
  private static void moveToNewLocation(Scanner scanner) {
    System.out.println("Enter the location to move to:");
    String newLocation = scanner.nextLine();
    
    Iterator<String> connections = game.getConnectionsIterator(currentLocation);
    boolean validMove = false;
    
    while (connections.hasNext()) {
      String connectedLocation = connections.next();
      if (connectedLocation.equals(newLocation)) {
        currentLocation = newLocation;
        System.out.println("Moved to " + currentLocation);
        validMove = true;
        break;
      }
    }
    
    if (!validMove) {
      System.out.println("Invalid move. Location not connected.");
    }
  }
  
  /**
   * Allows the player to search for a specific property (description) in the game.
   * The search is performed from the current location, and if the property is found,
   * the location where it is found is printed.
   * 
   * @param scanner Scanner object to read user input
   */
  private static String searchForProperty(String property) {
    String result = game.depthFirstSearch(currentLocation, property);
    
    if (result != null) {
      return "Found the property at: " + result;
    } else {
      return "Property not found.";
    }
  }
  
  /**
   * Saves the current game state to files. The user is prompted to enter the file paths for saving
   * both the locations' connections and descriptions, as well as the current location.
   * 
   * @param scanner Scanner object to read user input
   */
  private static void saveGameState() {
    
    try (PrintWriter currWriter = new PrintWriter(new FileWriter("currLocation"))) {
      currWriter.println(currentLocation); 
    } catch (IOException ioe) {
      
      System.err.println("Error saving the current location: " + ioe.getMessage());
    }
    
    
    game.saveGameState("c1", "d1");
    System.out.println("Game state saved successfully.");
  }
  
  
  /**
   * loads game state from previous game
   * 
   * @param scanner Scanner object to read user input
   */
  private static void loadGameState() {
    File currLocationFile = new File("currLocation");
    game = new GameLayout("c1", "d1");
    
    try (Scanner currScanner = new Scanner(currLocationFile)) {
      if (currScanner.hasNextLine()) {
        currentLocation = currScanner.nextLine().trim();
        System.out.println("Current location loaded: " + currentLocation);
      } else {
        System.out.println("No current location found in the file.");
      }
    } catch (IOException e) {
      System.err.println("Error reading current location file: " + e.getMessage());
    }
    
    
    switch(currentLocation){
      case "E1":
        TileManager.stage = 1;
        break;
      case "H1":
        TileManager.stage = 3;
        break;
      case "E2":
        TileManager.stage = 2;
        break;
      case "E3":
        TileManager.stage = 4;
        break;
      case "H2":
        TileManager.stage = 5;
        break;
      case "H3":
        TileManager.stage = 6;
        break;
      case "E4":
        TileManager.stage = 8;
        break;
      case "B":
        TileManager.stage = 9;
        break;
      case "D":
        TileManager.stage = 7;
        break;
      default:
         currentLocation = "S";
         TileManager.stage = 0;
         break;
      
    }
    
    gamePanel.tileM.loadMapForStage(TileManager.stage);
    AssetSetter assetSetter = new AssetSetter(gamePanel);
    assetSetter.setObject();
    
     switch(currentLocation){
      case "E1":
        gamePanel.player.x = gamePanel.tileSize * 4;
        gamePanel.player.y = gamePanel.tileSize * 20;
        break;
      case "H1":
                gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      case "E2":
             gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      case "E3":
        gamePanel.player.x = gamePanel.tileSize * 8;
        gamePanel.player.y = gamePanel.tileSize * 28;
        break;
      case "H2":
        gamePanel.player.x = gamePanel.tileSize * 13;
        gamePanel.player.y = gamePanel.tileSize * 24;
        break;
      case "H3":
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      case "E4":
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      case "B":
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      case "D":
        gamePanel.player.x = gamePanel.tileSize * 5;
        gamePanel.player.y = gamePanel.tileSize * 9;
        break;
      default:
        gamePanel.player.x = gamePanel.tileSize * 100;
        gamePanel.player.y = gamePanel.tileSize * 100;
         break;
      
    }
    gamePanel.repaint();
    gamePanel.requestFocusInWindow();
    
    
    System.out.println("Game state loaded successfully.");
  }
  
  
  
}

